function playSound() {
    const audio = document.getElementById("oceanAudio");
    audio.play();
}

// Countdown to a fixed date (example: 1 January 2027)
const countdownElement = document.getElementById("countdown");
const targetDate = new Date("January 1, 2027 00:00:00").getTime();

const interval = setInterval(function() {
    const now = new Date().getTime();
    const distance = targetDate - now;

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));

    countdownElement.innerHTML = days + " hari " + hours + " jam " + minutes + " menit lagi";

    if (distance < 0) {
        clearInterval(interval);
        countdownElement.innerHTML = "Saatnya Liburan ke Pantai! 🌴";
    }
}, 1000);
