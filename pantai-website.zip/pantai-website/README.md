# 🌊 Pesona Pantai Website

Project website sederhana bertema **Pantai** untuk kebutuhan commit GitHub.

## ✨ Fitur
- Desain bertema laut dan pantai
- Tombol suara ombak
- Countdown menuju liburan

## 🚀 Cara Menjalankan
1. Download file zip
2. Extract
3. Buka `index.html` di browser

## 📂 Struktur File
- index.html
- style.css
- script.js
- README.md
